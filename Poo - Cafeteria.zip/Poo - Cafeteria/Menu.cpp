#include "Menu.h"
#include <iostream>

void Menu::adicionarItem(const std::shared_ptr<Produto>& item) {
    itens.push_back(item);
}

bool Menu::realizarPedido(const std::string& nomeItem, int quantidade) {
    for (auto& item : itens) {
        if (item->getNome() == nomeItem) {
            std::cout << "Quantidade inicial do produto " << nomeItem << ": " << item->getQuantidade() << std::endl;
            if (item->getQuantidade() >= quantidade) {
                return true;
            } else {
                std::cerr << "Quantidade insuficiente para o produto: " << nomeItem << std::endl;
                return false;
            }
        }
    }
    std::cerr << "Produto não encontrado: " << nomeItem << std::endl;
    return false;
}

void Menu::exibirMenu() const {
    std::cout << "Menu da Cafeteria:" << std::endl;
    for (const auto& item : itens) {
        item->exibir();
    }
}

void Menu::verificarEstoque() const {
    std::cout << "Estoque da Cafeteria:" << std::endl;
    for (const auto& item : itens) {
        std::cout << "Produto: " << item->getNome() << ", Quantidade disponivel: " << item->getQuantidade() << std::endl;
    }
}

std::shared_ptr<Produto> Menu::getProduto(const std::string& nomeItem) const {
    for (const auto& item : itens) {
        if (item->getNome() == nomeItem) {
            return item;
        }
    }
    return nullptr;
}
