#ifndef PEDIDO_H
#define PEDIDO_H

#include <vector>
#include <memory>
#include "Produto.h"

class Pedido {
public:
    void adicionarProduto(std::shared_ptr<Produto> produto, int quantidade);
    double calcularTotal() const;
    void exibirPedido() const;
    void definirPagamento(const std::string& tipo, double valor);
    void apagarPedido(); 

private:
    struct ItemPedido {
        std::shared_ptr<Produto> produto;
        int quantidadePedida;

        ItemPedido(std::shared_ptr<Produto> p, int q) : produto(p), quantidadePedida(q) {}
    };

    std::vector<ItemPedido> itens;
    std::string metodoPagamento;
    double total;
};

#endif