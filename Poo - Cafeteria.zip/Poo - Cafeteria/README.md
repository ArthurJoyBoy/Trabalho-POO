Para rodar o programa:
Execute esse comando no terminal: 
    g++ -g Bebida.cpp Cliente.cpp Comida.cpp Menu.cpp Pagamento.cpp Pedido.cpp Produto.cpp main.cpp -o output/main.exe
E em seguida esse comando:
    ./output/main.exe



