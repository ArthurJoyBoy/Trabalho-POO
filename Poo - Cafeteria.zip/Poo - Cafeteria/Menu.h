#ifndef MENU_H
#define MENU_H

#include "Produto.h"
#include <vector>
#include <memory>

class Menu {
private:
    std::vector<std::shared_ptr<Produto>> itens;

public:
    void adicionarItem(const std::shared_ptr<Produto>& item);
    bool realizarPedido(const std::string& nomeItem, int quantidade);
    void exibirMenu() const;
    void verificarEstoque() const;
    std::shared_ptr<Produto> getProduto(const std::string& nomeItem) const;
};

#endif 
