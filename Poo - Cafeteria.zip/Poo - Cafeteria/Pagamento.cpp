#include "Pagamento.h"
#include <iostream>
#include <thread>
#include <chrono>

Pagamento::Pagamento(const std::string& tipo, double valor) : tipo(tipo), valor(valor) {}

void Pagamento::processarPagamento() const {
    std::cout << "Processando pagamento de $" << valor << " via " << tipo << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(4)); 
    std::cout << "Pagamento concluido." << std::endl;
}