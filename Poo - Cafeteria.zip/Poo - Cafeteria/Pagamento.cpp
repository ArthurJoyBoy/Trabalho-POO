#include "Pagamento.h"
#include <iostream>

Pagamento::Pagamento(const std::string& tipo, double valor) : tipo(tipo), valor(valor) {}

void Pagamento::processarPagamento() const {
    std::cout << "Pagamento concluido." << std::endl;
}