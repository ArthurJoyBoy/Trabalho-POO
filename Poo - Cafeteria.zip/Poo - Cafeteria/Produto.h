#ifndef PRODUTO_H
#define PRODUTO_H

#include <string>
#include <iostream>
#include <algorithm>

class Produto {
protected:
    std::string nome;
    double preco;
    int quantidade;

public:
    Produto(const std::string& nome, double preco, int quantidadeInicial);
    virtual ~Produto() = default;

    virtual void exibir() const;
    int vender(int quantidadePedida);
    int solicitarQuantidade(int quantidadePedida);
    void atualizarEstoque(int quantidadeVendida);

    std::string getNome() const;
    double getPreco() const;
    int getQuantidade() const;
    void setPreco(double preco);
    void setQuantidade(int quantidade);
};

#endif 
