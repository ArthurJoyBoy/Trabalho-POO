#include <iostream>
#include <string>
#include "Cliente.h"
#include "Menu.h"
#include "Produto.h"
#include "Bebida.h"
#include "Comida.h"
#include "Pagamento.h"
#include <thread>

int main() {
    std::string nomeCliente;
    int escolha = 0;
    
    std::cout << "Bem-vindo a Cafeteria!" << std::endl;
    std::cout << "Por favor, digite seu nome: ";
    getline(std::cin, nomeCliente);
    
    Cliente cliente;
    cliente.setNome(nomeCliente);
    Menu menu;

    menu.adicionarItem(std::make_shared<Bebida>("Cafe", 2.50, false, 10));  
    menu.adicionarItem(std::make_shared<Comida>("Bolo", 3.00, 250, 5)); 
    menu.adicionarItem(std::make_shared<Bebida>("Refri", 2.00, true, 20));
    menu.adicionarItem(std::make_shared<Comida>("Pao de Queijo", 1.50, 100, 15));
    
    do {
        std::cout << "\nO que voce gostaria de fazer?" << std::endl;
        std::cout << "1. Mostrar Menu" << std::endl;
        std::cout << "2. Verificar disponibilidade de estoque" << std::endl;
        std::cout << "3. Fazer um pedido" << std::endl;
        std::cout << "4. Ver pedido" << std::endl;
        std::cout << "5. Realizar pagamento" << std::endl;
        std::cout << "6. Sair" << std::endl;
        std::cout << "Escolha uma opcao: ";
        std::cin >> escolha;
        
        std::cin.ignore(); 

        switch (escolha) {
            case 1:
                menu.exibirMenu();
                break;
            case 2:
                menu.verificarEstoque();
                break;
            case 3:
                {
                    std::string nomeProduto;
                    int quantidade;
                    std::cout << "Digite o nome do produto: ";
                    getline(std::cin, nomeProduto);
                    std::cout << "Digite a quantidade desejada: ";
                    std::cin >> quantidade;
                    std::cin.ignore();  
                    auto produto = menu.getProduto(nomeProduto);
                    if (produto) {
                        cliente.fazerPedido(produto, quantidade, menu);
                        std::cout << "Pedido realizado com sucesso!" << std::endl;
                    } else {
                        std::cout << "Nao foi possivel realizar o pedido. Produto nao disponivel ou quantidade insuficiente." << std::endl;
                    }
                }
                break;
            case 4:
                std::cout << "Pedido do Cliente: " << cliente.getNome() << std::endl;
                cliente.exibirPedido();
                break;
            case 5:
                {
                    double valorPagamento = cliente.calcularTotalPedido();
                    std::string tipoPagamento;
                    std::cout << "Digite o tipo de pagamento (Dinheiro, Cartao, Pix): ";
                    getline(std::cin, tipoPagamento);
                    cliente.realizarPagamento(tipoPagamento, valorPagamento);
                    if (tipoPagamento == "Dinheiro" || tipoPagamento == "Cartao" || tipoPagamento == "Pix") {
                        
                        Pagamento pagamento(tipoPagamento, valorPagamento);
                        pagamento.processarPagamento();
                        std::cout << "Pagamento realizado com sucesso. Valor: $" << valorPagamento << std::endl;
                    }
                }
                break;
            case 6:
                std::cout << "Obrigado por usar a Cafeteria. Ate logo!" << std::endl;
                break;
            default:
                std::cout << "Opcao invalida. Tente novamente." << std::endl;
        }
    } while (escolha != 6);
    
    return 0;
}
