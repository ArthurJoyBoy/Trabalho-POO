#ifndef CLIENTE_H
#define CLIENTE_H

#include "Pedido.h"
#include "Menu.h"
#include <string>
#include <memory>

class Cliente {
private:
    std::string nome;
    std::shared_ptr<Pedido> pedido;

public:
    Cliente();
    bool podeRealizarPedido() const;
    void fazerPedido(const std::shared_ptr<Produto>& produto, int quantidade, Menu& menu);
    void exibirPedido() const;
    void realizarPagamento(const std::string& tipo, double valor);
    void setNome(const std::string& novoNome);
    std::string getNome() const;
    double calcularTotalPedido() const;
};

#endif
