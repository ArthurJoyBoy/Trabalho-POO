#include "Comida.h"

Comida::Comida(const std::string& nome, double preco, int calorias, int quantidadeInicial)
    : Produto(nome, preco, quantidadeInicial), calorias(calorias) {}

void Comida::exibir() const {
    Produto::exibir();
    std::cout << "Calorias: " << calorias << std::endl;
}
