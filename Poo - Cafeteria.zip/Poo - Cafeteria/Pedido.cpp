#include "Pedido.h"
#include <iostream>

void Pedido::adicionarProduto(std::shared_ptr<Produto> produto, int quantidade) {
    itens.emplace_back(produto, quantidade);
}

double Pedido::calcularTotal() const {
    double total = 0;
    for (const auto& item : itens) {
        total += item.produto->getPreco() * item.quantidadePedida;
    }
    return total;
}

void Pedido::exibirPedido() const {
    for (const auto& item : itens) {
        std::cout << "Produto: " << item.produto->getNome() << ", Quantidade: " << item.quantidadePedida << std::endl;
    }
    std::cout << "Total: $" << calcularTotal() << std::endl;
}

void Pedido::definirPagamento(const std::string& tipo, double valor) {
    metodoPagamento = tipo;
    total = valor;
}

void Pedido::apagarPedido() {
    itens.clear();
}