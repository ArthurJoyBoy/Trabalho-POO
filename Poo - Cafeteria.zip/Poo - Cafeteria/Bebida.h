#ifndef BEBIDA_H
#define BEBIDA_H

#include "Produto.h"

class Bebida : public Produto {
private:
    bool gelada;

public:
    Bebida(const std::string& nome, double preco, bool gelada, int quantidadeInicial);
    void exibir() const override;
};

#endif 
