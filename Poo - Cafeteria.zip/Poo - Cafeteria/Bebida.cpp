#include "Bebida.h"

Bebida::Bebida(const std::string& nome, double preco, bool gelada, int quantidadeInicial)
    : Produto(nome, preco, quantidadeInicial), gelada(gelada) {}

void Bebida::exibir() const {
    Produto::exibir();
    std::cout << "Gelada: " << (gelada ? "Sim" : "Nao") << std::endl;
}
