#include "Produto.h"

Produto::Produto(const std::string& nome, double preco, int quantidadeInicial)
    : nome(nome), preco(preco), quantidade(quantidadeInicial) {}

void Produto::exibir() const {
    std::cout << "Nome: " << nome << ", Preco: $" << preco << ", Quantidade em Estoque: " << quantidade << std::endl;
}

int Produto::vender(int quantidadePedida) {
    int quantidadeVendida = solicitarQuantidade(quantidadePedida);
    atualizarEstoque(quantidadeVendida);
    return quantidadeVendida;
}

int Produto::solicitarQuantidade(int quantidadePedida) {
    return std::min(quantidade, quantidadePedida);
}

void Produto::atualizarEstoque(int quantidadeVendida) {
    quantidade -= quantidadeVendida;
}

std::string Produto::getNome() const {
    return nome;
}

double Produto::getPreco() const {
    return preco;
}

int Produto::getQuantidade() const {
    return quantidade;
}

void Produto::setPreco(double preco) {
    if (preco >= 0) {
        this->preco = preco;
    } else {
        std::cerr << "Preço não pode ser negativo." << std::endl;
    }
}

void Produto::setQuantidade(int quantidade) {
    if (quantidade >= 0) {
        this->quantidade = quantidade;
    } else {
        std::cerr << "Quantidade não pode ser negativa." << std::endl;
    }
}
