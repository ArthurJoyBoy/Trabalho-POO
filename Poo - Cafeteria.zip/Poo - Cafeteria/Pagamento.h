#ifndef PAGAMENTO_H
#define PAGAMENTO_H

#include <string>

class Pagamento {
private:
    std::string tipo;
    double valor;

public:
    Pagamento() : tipo("indefinido"), valor(0.0) {}
    Pagamento(const std::string& tipo, double valor);

    void processarPagamento() const;
};

#endif 
