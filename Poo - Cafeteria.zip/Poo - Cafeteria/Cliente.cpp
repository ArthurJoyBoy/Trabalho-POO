#include "Cliente.h"
#include <iostream>

Cliente::Cliente() : pedido(std::make_shared<Pedido>()) {}

bool Cliente::podeRealizarPedido() const {
    if (nome.empty()) {
        std::cerr << "Erro: Nome do cliente não pode ser vazio para realizar pedidos." << std::endl;
        return false;
    }
    return true;
}

void Cliente::fazerPedido(const std::shared_ptr<Produto>& produto, int quantidade, Menu& menu) {
    if (!podeRealizarPedido()) return;
    if (produto->getQuantidade() >= quantidade) {
        produto->vender(quantidade);
        pedido->adicionarProduto(produto, quantidade);
    } else {
        std::cerr << "Quantidade insuficiente para o produto: " << produto->getNome() << std::endl;
    }
}

void Cliente::exibirPedido() const {
    pedido->exibirPedido();
}

void Cliente::realizarPagamento(const std::string& tipo, double valor) {
    if (!podeRealizarPedido()) return;
    if (tipo == "Dinheiro" || tipo == "Cartao" || tipo == "Pix") {
        pedido->definirPagamento(tipo, valor);
        pedido->apagarPedido();
        std::cout << "Pedido removido." << std::endl;
    } else {
        std::cerr << "Tipo de pagamento invalido. Use Dinheiro, Cartao ou Pix." << std::endl;
    }
}

void Cliente::setNome(const std::string& novoNome) {
    if (!novoNome.empty()) {
        nome = novoNome;
        std::cout << "Nome configurado: " << nome << std::endl;
    } else {
        std::cerr << "Erro: Nome não pode ser vazio." << std::endl;
    }
}

std::string Cliente::getNome() const {
    return nome;
}

double Cliente::calcularTotalPedido() const {
    return pedido->calcularTotal();
}