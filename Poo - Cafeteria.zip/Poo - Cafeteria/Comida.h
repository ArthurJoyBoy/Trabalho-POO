#ifndef COMIDA_H
#define COMIDA_H

#include "Produto.h"

class Comida : public Produto {
private:
    int calorias;

public:
    Comida(const std::string& nome, double preco, int calorias, int quantidadeInicial);
    void exibir() const override;
};

#endif
